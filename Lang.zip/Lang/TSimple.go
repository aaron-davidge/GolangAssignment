package main

import (
	"fmt"
)

func main() {

	fmt.Println("Hello World, This is a GoLang Demonstration.")
	fmt.Println("Welcome to the Main Method.")

	TSub()
	TVar()
	TLoop()
	TSel()
	GoWebServer()
}
